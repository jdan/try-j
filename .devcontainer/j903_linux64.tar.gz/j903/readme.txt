
https://www.jsoftware.com
https://code.jsoftware.com/wiki/System/Jsoftware_License
http://code.jsoftware.com/wiki/System/Installation
