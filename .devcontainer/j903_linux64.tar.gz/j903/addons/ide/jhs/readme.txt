The ide/jhs addon is the JHS IDE for j701 and later releases.

